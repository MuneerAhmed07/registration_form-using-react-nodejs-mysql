import RegistrationForm from './components/RegistrationForm';
import './App.css';

function App() {
  return (
    <div className="App">
      <RegistrationForm />
    </div>
  );
}

export default App;
