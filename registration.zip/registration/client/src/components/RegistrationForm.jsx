import { useState } from "react";
import axios from 'axios';

const RegistrationForm = () => {

    const [formData, setFormData] = useState({
        username: '',
        email: '',
        password: '',
    });

    console.log(formData)

    // Get Form Value
    const handleChange = (e) => {
        setFormData({...formData, [e.target.name]: e.target.value})
    }

    // handle Submit

    const handleSubmit = async (e) => {
        e.preventDefault();

        try{
            const response = await axios.post('http://localhost:5000/register', formData)
            alert(response.data);
        }catch(error){
            console.log("Error registering user", error);
            alert("Failed to register user");
        }
    }

    return (
        <>
            <div className="form-container">
                <h2>Register</h2>
                <form onSubmit={handleSubmit} className='form'>
                    <div className="input-group">
                        <label htmlFor="username">Username</label>
                        <input type="text"
                            id='username'
                            name='username'
                            placeholder='Enter your name'
                            autoComplete='off'
                            onChange={handleChange}
                            value={formData.username}
                            required
                        />
                    </div>
                    <div className="input-group">
                        <label htmlFor="email">Email</label>
                        <input type="email"
                            name='email'
                            placeholder='Enter your email'
                            autoComplete='off'
                            onChange={handleChange}
                            value={formData.email}
                            required
                        />
                    </div>
                    <div className="input-group">
                        <label htmlFor="password">Passwords</label>
                        <input type="password"
                            name='password'
                            placeholder='Enter your password'
                            autoComplete='off'
                            onChange={handleChange}
                            value={formData.password}
                            required
                        />
                    </div>
                    <button type='submit'>Register User</button>
                </form>
            </div>
        </>
    )
}

export default RegistrationForm;
